CHANGELOG
=========

V 1.1.0
-------
 - Gulp update to v4
 - Jquery version updated

V 1.0.0
-------
 - Initial release