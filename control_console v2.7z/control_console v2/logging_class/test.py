from demo_02 import Log

Log.info("hahahaha")