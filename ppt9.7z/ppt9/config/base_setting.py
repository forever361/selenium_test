import os
from application import app

HomePath = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
DEBUG = True

SQLALCHEMY_DATABASE_URI = "mysql://root:wesoftar@47.113.185.98/movie_cat"
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQLALCHEMY_ECHO = False

SECRET_KEY= "kun"
AUTH_COOKIE_NAME = "kun"



DOMAIN = {
    "www":"http://127.0.0.1:8899",
    "www2":"http://47.113.185.98:8899",
}

#RELEASE_PATH =  (HomePath)+'/release_version'
