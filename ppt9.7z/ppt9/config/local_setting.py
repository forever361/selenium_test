from application import app

app.config['SQLALCHEMY_DATABASE_URI']= "mysql://root:wesoftar@47.113.185.98/movie_cat"
SQLALCHEMY_TRACK_MODIFICATIONS = True
SQLALCHEMY_ECHO = True

