from controllers import index,member
from run import app

app.register_blueprint(index.web)
app.register_blueprint(member.web)

from interceptors.Auth import *

from common.libs.UrlManager import UrlManager
app.add_template_global(UrlManager.buildStaticUrl,'buildStaticUrl')
app.add_template_global(UrlManager.buildUrl,'buildUrl')


