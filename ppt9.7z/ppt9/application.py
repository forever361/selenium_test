import os

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_apscheduler import APScheduler

app = Flask(__name__)

app.config.from_pyfile("config/base_setting.py")
#ops_confgi=local|production
#linux export ops_confgi=local|production
#win set ops_confgi=local|production
if "ops_config" in os.environ:
    app.config.from_pyfile("config/%s_setting.py"%(os.environ['ops_config']))

db = SQLAlchemy( app  )

# scheduler = APScheduler()
# scheduler.init_app(app)
