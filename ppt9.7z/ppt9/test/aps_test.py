from apscheduler.schedulers.blocking import BlockingScheduler
import datetime

def asp_test():
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

scheduler =BlockingScheduler (timezone="Asia/Shanghai")
scheduler.add_job(func=asp_test,trigger="cron",second="*/5")
scheduler.start()