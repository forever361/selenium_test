from flask_script import Command
class MovieJob(Command):
    def run(self):
        print('123')