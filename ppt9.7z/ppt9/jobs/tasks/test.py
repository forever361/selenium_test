
class JobTask():
    def __init__(self):
        pass

    def run(self,params):
        print("job test print")
        print (params)