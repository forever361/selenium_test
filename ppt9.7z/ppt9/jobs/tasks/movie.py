import json
import os
import time

from application import app,db
import requests,hashlib
from bs4 import BeautifulSoup
from common.libs.DateHelper import getCurrentTime
from urllib.parse import urlparse
from common.models.movie import Movie

#python manager.py runjob -m movie -a down/local

class JobTask():
    def __init__(self):
        self.source = "pkmp4"
        self.url = {
            "num":5,
            "url":"https://www.pkmp4.xyz/vt/1-#d#.html",
            # "path": "/tmp/%s/"%(self.source)
            "path": "D:/WORM/%s/" % (self.source)
        }

    def run(self,params):
        # url = "https://www.pkmp4.xyz/vt/1-1.html"
        # res = requests.get(url)
        # soup = BeautifulSoup(res.content,"html.parser")
        # tmp_list = soup.select("div.main ul li")
        # for item in tmp_list:
        #     tmp_target = item.select("div.li-img a")
        #     tmp_name = tmp_target[0]['title']
        #     tmp_url = tmp_target[0]['href']
        #     print (tmp_name,tmp_url)
        #     break
        act = params['act']
        # self.date = getCurrentTime(frm = "%Y%m%d")
        self.date = "20220507"
        #下载的动作
        if act == "down":
            self.getList()
        # 从本地文件解析到数据库的过程
        elif act == "local":
            self.get_parse()


    #主函数
    def getList(self):
        config = self.url
        path_root =config['path'] + self.date
        path_list = path_root + '/list'
        path_info = path_root + '/info'
        path_json = path_root + '/json'
        self.makeSourDirs(path_root)
        self.makeSourDirs(path_list)
        self.makeSourDirs(path_info)
        self.makeSourDirs(path_json)

        pages = range(1,config['num']+1)
        for idx in pages:
            tmp_path = path_list + "/" +str(idx)
            tmp_url = config['url'].replace("#d#",str(idx))
            # print (tmp_path, tmp_url)
            if os.path.exists (tmp_path):
                continue
            #通过url拿页面里面的内容
            tmp_content = self.getHttpContent(tmp_url)
            # 将页面内容写入到本地文件
            self.saveContent(tmp_path,tmp_content)

            time.sleep(0.42)

        """
        下载和解析分离的模式
        1.下载几页数据到list，上面一段全部是实现这个功能
        2.根据list里面每个影剧，提取出核心的三个要素：name, url, hash(根据url生成)
        3.将每一个剧集核心要素，保存到以hash命名的json文件，以及将每个剧集url对应的页面下载到info文件夹
        """
        #核心
        for idx in os.listdir(path_list):
            #拿到本地下载的页面文件信息
            tmp_content = self.getContentfromLocal(path_list + "/" +str(idx))
            #生成核心的三个要素
            items_data = self.parseList(tmp_content)
            if not items_data:
                continue

            n=1
            # 生成核心的三个要素
            for item in items_data:
                tpm_json_path = path_json + "/" +item["hash"]
                tmp_info_path = path_info + "/" +item["hash"]
                if not os.path.exists(tpm_json_path):
                    self.saveContent(tpm_json_path,json.dumps(item,ensure_ascii=False))

                if not os.path.exists(tmp_info_path):
                    tmp_content = self.getHttpContent(item["url"])
                    self.saveContent(tmp_info_path,tmp_content)
                    print("保存第%s个文件.." % n)
                    n = n + 1

                time.sleep(0.3)

            print("保存完成..。。。")

    #解析每个影视页面
    def get_parse(self):
        config =self.url
        path_root =config['path'] + self.date
        path_list = path_root + '/list'
        path_info = path_root + '/info'
        path_json = path_root + '/json'
        for filename in os.listdir(path_info):
            tmp_json_path = path_json + "/" + filename
            tmp_info_path = path_info + "/" + filename
            #将json文件中保存的内容，进行解析
            tmp_data = json.loads(self.getContentfromLocal(tmp_json_path),encoding ="UTF-8" )
            # 对每一影视的页面进行解析
            tmp_content = self.getContentfromLocal(tmp_info_path)
            tmp_soup = BeautifulSoup (tmp_content,"html.parser")

            try:
                tmp_public_date = tmp_soup.select("div.main-ui-meta div.otherbox em")[1].getText()
                tmp_desc = tmp_soup.select("div.movie-introduce p")[1].getText().strip().split('[收起部分]',-1)[0]
                tmp_role = tmp_soup.select("div.main-ui-meta  div ")[3].getText().strip().split('：',1)[1]
                tmp_classify = tmp_soup.select("div.main-ui-meta  div ")[4].getText().strip().split('：',1)[1]

                tmp_pic_list = tmp_soup.select("div.main-left div.wrap div.img img")
                tmp_pics =[]
                for tmp_pic in tmp_pic_list:
                    tmp_pics.append(tmp_pic['src'])

                #磁力链接处理
                # tmp_downlist = tmp_soup.select("div.down-list ul li a")
                # tmp_down_list =[]
                # for tmp_down in tmp_downlist:
                #     tmp_down_list.append(tmp_down['href'])
                # #list去重
                # tmp_down_list = list(dict.fromkeys(tmp_down_list))

                # 磁力链接处理方法2
                # tmp_dict={}
                # tmp_downlist = tmp_soup.select("div.down-list ul li a")
                # tmp_down_list_1 = []
                # for tmp_down in tmp_downlist:
                #     if "title" in str(tmp_down):
                #         list= str(tmp_down).split(' ')
                #         for i in list:
                #             if i.startswith('href=') or i.startswith('title='):
                #                 tmp_down_list_1.append(i.strip("href=").strip('title=').strip('"'))
                #去掉>\n
                # tmp_down_list = []
                # for i in tmp_down_list_1:
                #     if '>' in i:
                #         # print (i)
                #         tmp_down_list.append(i.split('>',-1)[1].strip('\n'))
                #     else:
                #         tmp_down_list.append(i)
                #
                # print(tmp_down_list)
                # break

                # 磁力链接处理方法3,
                # [['"magnet:?xt=urn:btih:836C66C230136E404586ED3A72525ECA85DBD3A6"', 'title="阳光电影ygdy8.黑镜：潘达斯奈基.BD.720p.中英双字幕.mkv[1.11G]"'], ['"magnet:?xt=urn:btih:20CAA5F97859AA99DB3FAF983B48556FA417E09C"'
                # , 'title="[电影天堂dy2018]黑镜：潘达斯奈基HD中字.mkv[1.03G]"']
                tmp_downlist = tmp_soup.select("div.down-list ul li a")
                tmp_down_list = []
                for tmp_down in tmp_downlist:
                    if "title" in str(tmp_down) and "ed2k" not in str(tmp_down):
                        list = str(tmp_down).strip('<a').strip('</a>').split('href=')[1].split('>')[0].split(' ')
                        tmp_down_list.append(list)

                print (tmp_down_list)


                tmp_data['pub_date'] = tmp_public_date
                tmp_data['desc'] = tmp_desc
                tmp_data['classify'] = tmp_classify.strip('\n')
                tmp_data['actor'] = tmp_role
                tmp_data['source'] = self.source
                tmp_data['create_time'] =  tmp_data['update_time'] = getCurrentTime()
                if tmp_pics:
                    tmp_data['cover_pic'] = tmp_pics[0]
                    tmp_data['pics'] = json.dumps(tmp_pics)
                if tmp_down_list:
                    tmp_data['magnet_url'] = json.dumps(tmp_down_list)
                # print (tmp_data)

                tmp_movie_info = Movie.query.filter_by(hash = tmp_data['hash']).first()
                if tmp_movie_info:
                    continue

                #插数据入库
                tmp_model_movie = Movie(**tmp_data)
                db.session.add(tmp_model_movie)
                db.session.commit()



            except Exception:
                continue
        return True



    def parseList(self,content):
        data = []
        config = self.url
        url_info = urlparse(config['url'])
        url_domain = url_info[0]+"://"+url_info[1]
        tmp_soup = BeautifulSoup(str(content),"html.parser")
        tmp_list = tmp_soup.select("div.main ul li")
        for tmp_item in tmp_list:
            tmp_target = tmp_item.select("div.li-img a")
            tmp_name = tmp_target[0]['title']
            tmp_href = tmp_target[0]['href']
            if "http" not in tmp_href:
                tmp_href = url_domain + tmp_href

            tmp_data = {
                "name": tmp_name,
                "url": tmp_href,
                "hash": hashlib.md5(tmp_href.encode("UTF-8")).hexdigest()
            }
            data.append(tmp_data)
        #返回一个列表，保存剧集的三要素
        return data


    def getContentfromLocal(self,path):
        if os.path.exists(path):
            with open (path,mode="r",encoding="UTF-8") as f:
                return f.read()
        return


    def getHttpContent(self,url):
        try:
            r = requests.get(url)
            if r.status_code != 200:
                return None
            return r.content

        except Exception:
            return None

    def saveContent(self,path,content):
        if content:
            with open (path,mode="w+",encoding="UTF-8") as f:
                if type(content)!=str:
                    content =content.decode("utf-8")
                f.write(content)
                f.flush()
                f.close()

    def makeSourDirs(self,path):
        if not os.path.exists(path):
            os.makedirs(path)

