import sys,argparse
import traceback
import importlib

from flask_script import Command


class runjob (Command):
    capture_all_args = True
    def run(self,*args,**kwargs):
        args = sys.argv[2:]
        # print (sys.argv)
        parse = argparse.ArgumentParser(add_help=True)
        parse.add_argument("-m","--name",dest="name",metavar="name",help="指定jobname",required=True)
        parse.add_argument("-a","--act",dest="act",metavar="act",help="job action",required=False)
        parse.add_argument("-p", "--param", dest="param", nargs="*", metavar="param", help="业务参数", required=False)

        params = parse.parse_args(args)
        # print (params)
        params_dict = params.__dict__
        # print (params_dict)
        if "name" not in params_dict or not params_dict['name']:
            return self.tips()
        try:
            module_name = params_dict["name"].replace("/",".")
            import_string = "jobs.tasks.%s"%(module_name)
            target = importlib.import_module(import_string)
            exit(target.JobTask().run(params_dict))
            print (import_string)
        except Exception as e:
            traceback.print_exc()
        return

    def tips(self):
        tip_msg = '''
        请正确调度job
        python manager.py runjob -m Test (jobs/tasks/test.py)
        python manager.py runjob -m test -a list -p 1 2 3
        '''
        print (tip_msg)
        return