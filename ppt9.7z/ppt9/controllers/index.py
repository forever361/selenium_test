import math
import json
from flask import Blueprint, make_response, jsonify, render_template, session, request, redirect
from sqlalchemy import text, func
from application import db, app
from common.libs.Helper import ops_render,iPagination
from common.libs.UrlManager import UrlManager
from common.models.movie import Movie

web = Blueprint("user", __name__)


@web.route('/')
def index():

    reg = request.values
    page = 1
    if 'p' in reg and reg['p']:
        page = int(reg['p'])


    query = Movie.query

    page_params ={
        'total_count':query.count(),
        'page_size':30,
        'page':page,
        'url':"/?",
    }


    pages = iPagination(page_params)

    #0-30.30-60
    offset = (page - 1) * page_params['page_size']
    limit = page * page_params['page_size']

    list_movie  = query.order_by(Movie.pub_date.desc(),Movie.id.desc())[offset : limit]

    return ops_render('index.html',{"data":list_movie,"pages":pages})



@web.route("/info")
def info():

    req = request.values
    id = int(req['id']) if('id' in req and req['id'] ) else 0
    if id <1:
        return redirect(UrlManager.buildUrl("/"))
    info = Movie.query.filter_by( id = id).first()

    if not info:
        return redirect(UrlManager.buildUrl("/"))

    #对磁力链接的处理
    magnet_url = json.loads(info.magnet_url) if info.magnet_url else ''

    #更新页面阅读量
    info.view_counter += 1
    db.session.add(info)
    db.session.commit()

    #获取推荐
    recommend_list = Movie.query.order_by( func.rand()).limit(4)

    return ops_render('info.html',{"info" : info, "magnet_url_list":magnet_url, "recommend_list":recommend_list})
