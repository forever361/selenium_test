from flask import Blueprint, render_template,request,make_response,redirect
from common.libs.Helper import ops_rederJSON, ops_rederErrJSON, ops_render
from common.libs.UrlManager import UrlManager
from common.models.user import User
from common.libs.UserService import UserService
from common.libs.DateHelper import getCurrentTime

from application import app, db

web = Blueprint("member", __name__)

@web.route('/member/reg',methods = ["GET","POST"])
def reg():
    if request.method == 'GET':
        return ops_render("/member/reg.html")
    req = request.values
    login_name = req['login_name'] if "login_name" in req else ""
    login_pwd = req['login_pwd'] if "login_pwd" in req else ""
    login_pwd2 = req['login_pwd2'] if "login_pwd2" in req else ""

    #前端不验证只是用户界面不太友好，后端这里不验证结果是相当严重，一旦前端被穿透，谁都可以登录
    if login_name is None or len(login_name)<1:
        return ops_rederErrJSON(msg = "请输入正确的用户名")
    if login_pwd is None or len(login_pwd)<6:
        return ops_rederErrJSON(msg = "密码不小于6位")
    if login_pwd2 is None or login_pwd2 != login_pwd:
        return ops_rederErrJSON(msg = "两次密码输入不一致")

    user_info = User.query.filter_by(login_name =login_name ).first()
    if user_info:
        return ops_rederErrJSON(msg="用户已存在")

    model_user = User()
    model_user.login_name =login_name
    model_user.nikename =login_name
    model_user.login_salt = UserService.genSalt(8)
    model_user.login_pwd = UserService.genPwd(login_pwd,model_user.login_salt)
    model_user.create_time = model_user.update_time = getCurrentTime()
    db.session.add(model_user)
    db.session.commit()
    return ops_rederJSON(msg="注册成功")

@web.route('/member/login',methods = ["GET","POST"])
def login():
    if request.method == 'GET':
        return ops_render("/member/login.html")
    req = request.values
    login_name = req['login_name'] if "login_name" in req else ""
    login_pwd = req['login_pwd'] if "login_pwd" in req else ""

    # 前端不验证只是用户界面不太友好，后端这里不验证结果是相当严重，一旦前端被穿透，谁都可以登录
    if login_name is None or len(login_name) < 1:
        return ops_rederErrJSON(msg="请输入正确的用户名")
    if login_pwd is None or len(login_pwd) < 6:
        return ops_rederErrJSON(msg="请输入正确的密码")

    user_info = User.query.filter_by(login_name=login_name).first()
    if not user_info:
        return ops_rederErrJSON(msg="请输入正确的用户名和密码 -1")
    if user_info.login_pwd != UserService.genPwd(login_pwd,user_info.login_salt):
        return ops_rederErrJSON(msg="请输入正确的用户名和密码 -2")

    if user_info.status !=1:
        return ops_rederErrJSON(msg="账号禁用")

    response= make_response(ops_rederJSON(msg="登录成功"))
    response.set_cookie(app.config['AUTH_COOKIE_NAME'],"%s#%s"%(UserService.genAuthCode(user_info),user_info.id),60*60*24*100)
    return response


@web.route('/member/logout')
def logout():
    response = make_response(redirect(UrlManager.buildUrl("/")))
    response.delete_cookie(app.config['AUTH_COOKIE_NAME'])
    return response
