from  application import app
from flask import request,g

from common.libs import UserService
from common.models.user import User

#在所有请求时，先执行
@app.before_request
def before_request():
    user_info = check_login()
    g.current_user = None

    #如果用户登陆了，就把当前用户信息赋值给g全局变量
    if user_info:
        g.current_user= user_info
    # app.logger.info("----------before-------")
    return


@app.after_request
def after_request(response):
    # app.logger.info("----------after-------")
    return response

def check_login():
    cookie = request.cookies
    cookie_name = app.config['AUTH_COOKIE_NAME']
    auth_cookie = cookie[cookie_name] if cookie_name in cookie else None

    if auth_cookie is None:
        return False
    auth_info = auth_cookie.split("#")
    if len(auth_info) != 2:
        return False
    try:
        user_info = User.query.filter_by(id =auth_info[1]).first()
        # print ('user_info',user_info)
    except Exception:
        return False

    if user_info is None:
        return False


    if auth_info[0] != UserService.UserService.genAuthCode(user_info):
        return False

    return (user_info)