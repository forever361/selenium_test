from application import app
from www import *
from flask_script import Manager,Command
from jobs.laucher import runjob

manager = Manager(app)

from flask_script import Server
manager.add_command("runserver",Server(host="0.0.0.0",port=8899,use_debugger=True,use_reloader=True))

manager.add_command("runjob",runjob)


@Command
def creat_all():
    from application import  db
    from common.models.user import User
    db.create_all()

manager.add_command("creat_all",creat_all)

def main():
    manager.run()

#web server
if __name__ == '__main__':
    try:
        import sys
        sys.exit(main())
    except Exception as e:
        import traceback
        traceback.print_exc()