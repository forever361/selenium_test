import datetime
from application import app
from www import *

def asp_test():
    print(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

#web server
if __name__ == '__main__':
    # app.apscheduler.add_job(func=asp_test,trigger="cron",second="*/5",id='asp_test')
    # scheduler.start()
    app.run(host="0.0.0.0",port=8899,debug=True,use_reloader=True)