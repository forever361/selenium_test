# coding: utf-8
from application import db


class User(db.Model):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    nikename = db.Column(db.String(30, 'utf8mb4_bin'))
    login_name = db.Column(db.String(20, 'utf8mb4_bin'), unique=True)
    login_pwd = db.Column(db.String(32, 'utf8mb4_bin'))
    login_salt = db.Column('login_salt', db.String(32, 'utf8mb4_bin'))
    status = db.Column(db.Integer, server_default=db.FetchedValue())
    update_time = db.Column(db.DateTime, server_default=db.FetchedValue())
    create_time = db.Column('create_time', db.DateTime, server_default=db.FetchedValue())
